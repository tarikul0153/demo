const prevBtn = document.querySelector('.prev');
const nextBtn = document.querySelector('.next');
const galerryImgs = document.querySelectorAll ('#gmap_canvas') // create a folder maps under images / if not working try .img
let currentlySelected = 0;

prevBtn.addEventListener('click', function() {  // we'll come back to you 

  galerryImgs[currentlySelected].classList.remove("active"); // second part to the the opposite for preivous button. 
  currentlySelected--;// here instead of going foward were going backward. and this sentence is the same has currentlySelected = currentlSelected - 1;
  galerryImgs[currentlySelected].classList.add("active");
  nextBtn.disabled = false;

  if (currentlySelected === 0) {
    prevBtn.disabled = true; 
    } // if the current map is the first one then the previous btn is disabled. so if we click preivous and come back to the first image = disabled btn 
   
}); 

nextBtn.addEventListener('click', function() {
  galerryImgs[currentlySelected].classList.remove("active"); // to remove the active element 
  currentlySelected++; // move so the currently selected is the next one. // its the same as currentlySelected = currentlySelected + 1
  galerryImgs[currentlySelected].classList.add("active"); // between both of lines gallery images i added 1 with curretlySelected++;
  prevBtn.disabled = false; // this is to be able to go back when we cick on a next btn bc now you have a previous map available
   
  if (galerryImgs.length === currentlySelected +1) { // so if that happen. to know that we're at the end of the maps. so to stop it. why +1? so if i have 12 maps the last one will be 11 bc we start at 0 with indexes. so currently selected is going to be 11 if we reach the end
    nextBtn.disabled = true; // so the button nw is disabled if we reach the last map 
  }
  
});



