const firstName = document.getElementById("firstname"); //get element by id only works with ID
const replyTo = document.getElementById("replyto");
const comments = document.getElementById("comments");
const project = document.getElementById("project");
const submitButton = document.getElementById("submitbutton");

firstName.addEventListener('change', valid ); // validator is the function to run when the evet (change) occurs
replyTo.addEventListener('change', valid ); //change is the event. The event occurs when the content of a form element, the selection, or the checked state have changed (for <input>, <select>, and <textarea>)
comments.addEventListener('change', valid );
project.addEventListener('change', valid );
function valid () {
     if (firstName.value === ' ' || comments.value === '' || replyTo.value === ' ') { //space between '' means there is nothing
        submitButton.disabled = true;

     }  else {
        submitButton.disabled = false;
    }
        }