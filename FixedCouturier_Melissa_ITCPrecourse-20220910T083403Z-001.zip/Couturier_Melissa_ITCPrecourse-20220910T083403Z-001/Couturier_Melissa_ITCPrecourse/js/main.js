//replace with your user:
const GITHUB_URL = "https://api.github.com/users/Melissacouturier";

fetch(GITHUB_URL)
  .then(function(response) {
    return response.json(); // to be able to see infos in  body = response.json allow to transform ourr response to an JS object , interpretable by our browserm/ our response here is json, could be other stuff like text etc
  })
  .then(function (data) { // we get the data back 
    const profileImage = document.getElementById("profile-image");
    const profileName = document.getElementById("profile-name");
    // update the profileImage and profileName with the information retrieved
    profileImage.src = data.avatar_url;
    profileName.innerHTML = data.name;
  });

 
//function means you want to run a function.
//and you want to execute the command between the Brasses 
//why we need the function?
// encapsulation, code re-use "clean code"

// Anim click 
const card = document.getElementById("card");
card.addEventListener('click', (e) =>{ // le c cest l'bject de levenement. element.addEventListener(event, function, useCapture) / the e is an object containing information about the event that has just occurs (here click event). when you console log (e) then youll se different properties

  const rond = document.createElement('card');
  rond.className = 'clickAnim';
  rond.style.top = `${e.pageY - 50}px`; //-50px c la moitie de 100 sur le css pour quils apparaissent au milieu de notre click 
  rond.style.left = `${e.pageX - 50}px`;
  document.body.appendChild(rond);
  
  


})