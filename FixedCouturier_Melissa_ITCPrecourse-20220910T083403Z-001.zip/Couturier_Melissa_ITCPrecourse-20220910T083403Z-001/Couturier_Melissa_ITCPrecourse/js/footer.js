const codingLanguages = ["HTML", "CSS", "JavaScript"];
const spanElement = document.getElementById("coding-languages");

const formatter = new Intl.ListFormat('en', { style: 'long', type: 'conjunction'});
const wordFormat = formatter.format(codingLanguages);

spanElement.innerText = wordFormat;