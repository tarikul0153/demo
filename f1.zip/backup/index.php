<?php
include('common/header.php');
?>
<!--  Video section  Start-->
<section class="banner-section">
	<div class="video">
		<video autoplay muted loop id="myVideo">
			<source src="img/vd.mp4" type="video/mp4">
			Your browser does not support HTML5 video.
		</video>
	</div>
	<div class="banner-section-content">
		<h1>Contribute to <br>
		Global society <br>
		with IT</h1> 
		
		<p>ITでグローバル社会に貢献する</p>
	</div>
</section>
<!--  Video section  end-->

<!-- what's F1  start -->
<section class="what-f1">
	<div class="section-content-f1">
		
		<h1 class="what-f1-title">What's F1</h1>
		<p class="what-f1-title-content">株式会社F1は日本とバングラディシュを開発拠点として、グローバルに高品質なシステム開発とコーディング技術を提供いたします。<br> 日本品質のデザイン、ディレクション、マーケティング戦略を元に企業のITに貢献します。</p>
	</div>
	<img src="img/bg.png" alt="" class="bg-image">


</section>
<!-- what's F1  end -->


<section class="service-section" >
<div class="all-services">
	<!-- Service 1 -->
	<div class="sinlge-services service-one">
		<div class="service single-service-left">
			<img src="img/img_1.png" alt="" id="businessm"/>
		</div>
		<div class="service single-service-content single-service-right" id="businessf">
		<div id="businessi"></div>
			<h1 id="business">Web 制作、運用事業</h1>
			
			<p class="web-1">Webの企画からデザイン、コーディングまでお任せください。デザインは日本品質、コーディングはバングラディシュで行うことで価格優位性を出し高品質なサイトを提供いたします。日々の更新や運用業務を月額定額で請け負うことも可能です。</p>
		</div>
	</div>
	<!-- Service 1 end -->
	<!-- Service 2  -->
	<div class="sinlge-services service-two">
		
		<div class="service single-service-content single-service-left single-service-left-content">
			<h1>システム開発、</h1>
			<h1>アプリ開発</h1>
			<p class="web-2">Webシステムの受託開発及びアプリケーション開発、オフショア開発を請け負っております。クライアント専属の人員を確保しプロジェクトチームを組んで開発に取り組むこともできます。</p>
		</div> 
		<div class="service single-service-right service-image-two">
			<img src="img/img_2.png" alt="" class="single-service-right-image mobile-width">
		</div>
	</div>
	<!-- Service 2  end -->
	<!-- Service 3 -->
	<div class="sinlge-services service-three">
		<div class="service single-service-left">
			<img src="img/img_3.png" alt="">
		</div>
		<div class="service single-service-content single-service-right">
			<h1>グローバル人材育成</h1>
			<p class="web-3">日本のIT技術者不足を解消するために、バングラディシュ人材のIT技術と語学力をあげる教育を行っております。日本品質の教育を行うことで技術力、コミュニケーション力を高めて人材価値をあげる取り組みを行っております。</p>
		</div>
		
	</div>
<div id="recuritf"></div>
	<!-- Service end -->
</div>
</section>



<!-- Recurit Section start -->
<section class="recruits" id="recurit">
<h1 class="recruits-title"  id="recuriti">採用情報</h1>
<div class="main-recruits recurit-one">
	<div class="recruits-left">
		<p>職種</p>
	    <p>仕事内容</p>
	    <p>給与</p>
	    <p>応募方法</p>
	</div>

	<div class="recruits-right">
		<p>セールス</p>
	    <p>クライアントへＷＥＢ戦略やWebサイト企画の提案をして頂きます。</p>
	    <p>応相談</p>
	    <p>お問合せ頂き、履歴書、職務経歴書をお送りください。その後書類選考～面接～内定となります。</p>
	</div>
</div>
<div class="main-recruits recurit-two">
	<div class="recruits-left recurit-two-left">
		<p>職種</p>
	    <p>仕事内容</p>
	    <p>給与</p>
	    <p>応募方法</p>
	</div>

	<div class="recruits-right">
		 <p>ディレクター</p>
	    <p>クライアントのディレクション及び社内の進行管理やプロジェクトを遂行して頂きます。</p>
	    <p>応相談</p>
	    <p>お問合せ頂き、履歴書、制作実績をお送りください。その後書類選考～面接～内定となります。</p>
	</div>
</div>
<div id="about-usf"></div>
</section>

<!-- Recurit Section end   -->




<!-- Company Profile Start -->
<section class="company-profile section-padding" id="about-us">
<h1 class="company-profile-title" id="about-usm">会社概要</h1>
<div id="about-usi"></div>
<div class="main-company-content">
<div class="company-profile-left">
	<p>会社名</p>
	<p>住所</p>
	<p>電話番号</p>
	<p>FAX</p>
	<p>URL</p>
	<p>設立</p>
	<p>資本金</p>
	<p>代表者名</p>
	<p>取引銀行</p>
</div>

<div class="company-profile-right">
	<p>株式会社F1  /  F1 CO.,LTD</p>
	<p>〒110-0015東京都台東区東上野2-13-8アルカディア上野ビル8階</p>
	<p>03-5246-4710</p>
	<p>03-5246-4711</p>
	<p>http://www.f1</p>
	<p>2020年3月1日</p>
	<p>5,000,000円</p>
	<p>代表取締役ＣＥＯ石井欣哉</p>
</div>
</div>
</section>
<!-- Company Profile end -->
<!--  Map section  start-->
<div class="map">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3239.6758755037476!2d139.77584331525972!3d35.70959298018767!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x60188e78aaa69bdd%3A0xa4b41a89ebb08c44!2z77yI5qCq77yJ44Ki44Kk44Kx44Kk44Ov44Kk!5e0!3m2!1sja!2sjp!4v1585071364215!5m2!1sja!2sjp"  aria-hidden="false" title="map" tabindex="0"></iframe>
</div>
<!--  Map section  End-->
<div class="btn-section">
<a href="inquiry.php" class="btn">お問合せはこちら <img src="img/angle.png" alt="" class="btn-image-angle" /></a>
</div>
<?php
include('common/footer.php');
?>