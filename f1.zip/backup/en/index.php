<?php
include('common/header.php');
?>
<!--  Video section  Start-->
<section class="banner-section">
	<div class="video">
		<video autoplay muted loop id="myVideo">
			<source src="img/vd.mp4" type="video/mp4">
			Your browser does not support HTML5 video.
		</video>
	</div>
	<div class="banner-section-content">
		<h1>Contribute to <br>Global society <br>with IT</h1>
		<p>Contribute to the global society with IT</p>
	</div>
</section>
<!--  Video section  end-->


<!-- what's F1  start -->
<section class="what-f1">
	<div class="section-content-f1">
		
		<h1 class="what-f1-title">WHAT'S F1</h1> <br>
		<p class="what-f1-title-content">As ICT company based in Japan and Bangladesh, we provide high-quality system development and coding technology globally.
		With Japan quality of design, direction, marketing strategy, we commit to the realization of client's IT strategy.</p>
	</div>
	<img src="img/bg.png" alt="" class="bg-image">


</section>
<!-- what's F1  end -->


<section class="service-section" id="businessf">
<div class="all-services">
	<!-- Service 1 -->
	<div class="sinlge-services">
		<div class="single-service-left">
			<img src="img/img_1.png" alt="" id="businessm">
		</div>
		<div class="single-service-content single-service-right">
			<h1 id="business">Web site production and administration</h1>
			<p>You can order everithing on web production, planning, design, coding, etc. we produce high quality websites designed by Japan and coded by Bangladesh with reasonable cost we also take on daily updates and administration of website with monthly fee.</p>
		</div>
	</div>
	<!-- Service 1 end -->
	<!-- Service 2  -->
	<div class="sinlge-services">
		
		<div class="single-service-content single-service-left single-service-left-content">
			<h1>System and app develompent</h1>
			<p>We do entrusted development of web sysytem and application We can also organaze a project team for client.</p>
		</div>
		<div class="single-service-right service-image-two">
			<img src="img/img_2.png" alt="" class="single-service-right-image">
		</div>
	</div>
	<!-- Service 2  end -->
	<!-- Service 3 -->
	<div class="sinlge-services">
		<div class="single-service-left">
			<img src="img/img_3.png" alt="">
		</div>
		<div class="single-service-content single-service-right">
			<h1>Development of global human resources</h1>
			<p>In order to solve the IT engineer shortage in Japan, we do educational work to improve the IT and language skills of the Bangladesh Human Resources Enhancing IT and communication skill to increase value of human resources by Japan quality education system.</p>
		</div>
		
	</div>
	<div  id="recuritf"></div>
	<!-- Service end -->
</div>

</section>



<!-- Recurit Section start -->
<section class="recruits" id="recurit">
<h1 class="recruits-title" id="recuritm">Recruits</h1>
<div class="main-recruits recurits-one">
	<div class="recruits-left">
		<p> Occupations</p>
	    <p>Job Description</p>
	    <p>Salary</p>
	    <p>Apply</p>
	</div>

	<div class="recruits-right">
		 <p>Sales rep</p>
	    <p>
	Propose web stragety and web site planning to clients</p>
	    <p>Negotiable</p>
	    <p>Please send us your resume . After screening your resume, we do interview. Then we offer a position to you</p>
	</div>
</div>
<div class="main-recruits  recurits-two">
	<div class="recruits-left">
		<p> Occupations</p>
	    <p>Job Description</p>
	    <p>Salary</p>
	    <p>Apply</p>
	</div>

	<div class="recruits-right">
		 <p>Sales rep</p>
	    <p>
	Propose web stragety and web site planning to clients</p>
	    <p>Negotiable</p>
	    <p>Please send us your resume . After screening your resume, we do interview. Then we offer a position to you</p>
	</div>
</div>
<div id="about-usf"></div>
</section>

<!-- Recurit Section end   -->




<!-- Company Profile Start -->
<section class="company-profile section-padding"   id="about-us">
<h1 class="company-profile-title" id="about-usm">Company Profile</h1>
<div class="main-company-content">
<div class="company-profile-left">
	<p>Company </p>
	<p>Street address</p>
	<p>Phone number</p>
	<p>FAX</p>
	<p>URL</p>
	<p>Company registration date </p>
	<p>Capital</p>
	<p>Representative</p>
	<p>Bank</p>
</div>

<div class="company-profile-right">
	<p>株式会社F1  /  F1 CO.,LTD</p>
	<p> 〒110-0015  東京都台東区東上野2-13-8　アルカディア上野ビル8階 </p>
	<p> 03-5246-4710 </p>
	<p> 03-5246-4711 </p>
	<p> http://www.f1 </p>
	<p> 2020年3月1日 </p>
	<p> 5,000,000円 </p>
	<p>代表取締役ＣＥＯ 石井 欣哉</p>
</div>
</div>
</section>
<!-- Company Profile end -->
<!--  Map section  start-->
<div class="map">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3239.6758755037476!2d139.77584331525972!3d35.70959298018767!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x60188e78aaa69bdd%3A0xa4b41a89ebb08c44!2z77yI5qCq77yJ44Ki44Kk44Kx44Kk44Ov44Kk!5e0!3m2!1sja!2sjp!4v1585071364215!5m2!1sja!2sjp"  aria-hidden="false" tabindex="0" title="Map"></iframe>
</div>
<!--  Map section  End-->
<div class="btn-section">
<a href="inquiry.php" class="btn">お問合せはこちら<img src="img/angle.png" alt="" class="btn-image-angle" /></a>
</div>
<?php
include('common/footer.php');
?>