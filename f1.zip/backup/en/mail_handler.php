<?php
	if(isset($_POST['submit'])){
		$name=$_POST['name'];
		$email=$_POST['email'];
		$phone=$_POST['phone'];
		$phonetic=$_POST['phonetic'];
		$content_of_inquiry=$_POST['content_of_inquiry'];
		$address=$_POST['address'];
		$department=$_POST['department'];
		$inquiry=$_POST['inquiry'];
		$company=$_POST['company'];

		$to='jniqbal1@gmail.com'; // Receiver Email ID, Replace with your email ID
		$subject='Form Submission';
		$message=
		"Name :".$name."\n".
		"Phone :".$phone."\n".
		"Phonetic :".$phonetic."\n".
		"Email : ".$email."\n".
		"Address : ".$address."\n".
		"inquiry : ".$inquiry."\n".
		"company : ".$company."\n".
		"Department : ".$department."\n".
		"Content of Inquiry : ".$content_of_inquiry."\n".
		$headers="From: ".$email;

		if(mail($to, $subject, $message, $headers)){
			echo "<h1>Sent Successfully! Thank you"." ".$name.", We will contact you shortly!</h1>";
		}
		else{
			echo "Something went wrong!";
		}
	}
?>