<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title> F1co </title>
<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
<link rel="icon" href="img/favicon.ico" type="image/x-icon">
	<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=M+PLUS+1p|M+PLUS+Rounded+1c&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
</head>
<body>
<div id="top"></div>
<!--  Header Section Start -->
<header id="navbar">
	




	<div class="main-menu" id="main-menu">
		<nav>
			<div class="logo">
				<a href="./"><img src="img/logo.png" alt=""></a>
			</div>
			




			<div class="level-menu">
				<div class="header-top">
					<span><a href="#" title="Japanese">Japanese </a></span>
					<span> | </span>
					<span><a href="en" title="English"> English </a></span>
				</div>
				<ul>
					<li><a href="#top" title="Home">ホーム</a></li>
					<li><a href="#business" title="Business">事業内容</a></li>
					<li><a href="#recurit" title="Recurit">採用情報</a></li>
					<li><a href="#about-us" title="About us">会社概要</a></li>
					<li><a href="inquiry.php" title="Inquiry">お問合せ</a></li>
				</ul>
				
			</div>
			<div class="responsive-mebile-menu-icon">
				<a href="#" onclick="openNav()">
  &#9776; 
</a> <!-- <img src="img/menubar.png" alt=""  /> -->
			</div>
		</nav>
	</div>

<!--  Responsive menu  -->
<div id="humbargurMenu">
<div id="myNav" class="overlay">
	<div class="lang-menu">
	<span><a href="#">Japanese</a></span>
					<span class="line"> | </span>
					<span><a href="en"> English </a></span>
	</div>
  <a href="javaScript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <div class="overlay-content">
    <a href="#top" title="home">ホーム</a>
    <a href="#businessf" id="hideHumbergurMenu"  title="Business">事業内容</a>
    <a href="#recuritf" id="hideHumbergurMenu"  title="Recurit">採用情報</a>
    <a href="#about-usf" id="hideHumbergurMenu"  title="About us">会社概要</a>
    <a href="inquiry.php" id="hideHumbergurMenu"  title="Inquiry">お問合せ</a>
  </div>
</div>
</div>

</header>
<!--  Header Section End -->