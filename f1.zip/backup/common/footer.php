<!--  Footer Start -->
<footer>
	<div class="footer-display-flex">
		<div class="footer-logo">
			<img src="img/footer_logo.png" alt="">
		</div>
		<div class="footer-level-menu">
			<ul>
			
				<li><a href="#top" title="Home">ホーム</a></li>
				<li><a href="#businessf" title="Business">事業内容</a></li>
				<li><a href="#recuritf" title="Recurit">採用情報</a></li>
				<li><a href="#about-usf" title="About us">会社概要</a></li>
				<li><a href="inquiry.php" title="Inquiry">お問合せ</a></li>
			</ul>
		 <p class="copy-right-text"> &#169; 2020 F1.CO.LTD</p>
		</div>
	</div>
</footer>
<!--  Footer end -->
<script src="https://code.jquery.com/jquery-3.5.0.min.js"></script>
<script src="js/function.js"></script>
</body>
</html>