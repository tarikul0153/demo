<?php
include('common/inquiry-header.php');
?>
<section class="inquiry-section">
	<div class="inquiry-form">
		<div class="inquery-heading">
			<h1>お問合せ</h1>
			<p>お客さまからのご質問をお問い合わせフォームにて受け付けております。必要事項をご記入の上、「送信する」を押してください。</p>
		</div>
		<form action="mail_handler.php" method="post">
			
			<div class="single-input">
				<label for="inquiry" class="flex-basis">問い合わせ項目<span class="required">必須</span></label>
				
				<select name="inquiry" id="inquiry" class="input-style flex-basis width-2x select-input" tabindex="0" required>
					<option value="" selected> 選択してください</option>
					<option value="選択してください">選択してください</option>
					<option value="選択してください">選択してください</option>
					<option value="選択してください">選択してください</option>
				</select>
			</div>
			<div class="single-input">
				<label for="company"  class="flex-basis">企業名<span class="required">必須</span></label>
				<input type="text" id="company" value="" placeholder="" class="input-style flex-basis" name="company" required>
			</div>
			<div class="single-input">
				<label for="department"  class="flex-basis">部署名</label>
				<input type="text" value="" placeholder="" id="department" class="input-style flex-basis" name="department" required>
			</div>
			<div class="single-input">
				<label class="flex-basis" for="name">お名前<span class="required">必須</span></label>
				<input type="text" id="name" value="" placeholder="" class="input-style flex-basis width-2x" name="name" required>
			</div>
			<div class="single-input">
				<label class="flex-basis" for="phonetic">ふりがな</label>
				<input type="text" value="" placeholder="" id="phonetic" class="input-style flex-basis width-2x" name="phonetic">
			</div>
			<div class="single-input">
				<label class="flex-basis" for="email">メールアドレス<span class="required">必須</span></label>
				<input type="email" value="" placeholder="" id="email" class="input-style flex-basis" name="email" required>
			</div>
			<div class="single-input">
				<label class="flex-basis" for="phone">電話番号</label>
				<input type="text" value="" id="phone" placeholder="" class="input-style flex-basis width-2x" name="phone">
			</div>
			<div class="single-input">
				<label class="flex-basis" for="address">住所</label>
				<input type="text" value="" placeholder="" id="address" class="input-style flex-basis" name="address">
			</div>
			<div class="single-input">
				<label for="nonet">当社をどちらで知りましたか？</label>
				<input type="hidden" id="nonet">
				<div class="all-checkbox">
					<label class="single-checkbox" for="a">新聞
					  <input type="checkbox" id="a" value="">
					  <span class="checkmark"></span>
					</label>
					<label class="single-checkbox" for="b">雑誌
					  <input type="checkbox" id="b" value="">
					  <span class="checkmark"></span>
					</label>
					<label class="single-checkbox" for="c">検索エンジン
					  <input type="checkbox" id="c" value="">
					  <span class="checkmark"></span>
					</label>
					<label class="single-checkbox" for="d">その他サイト
					  <input type="checkbox" id="d" value="">
					  <span class="checkmark"></span>
					</label>
				</div>

			</div>
			<div class="single-input">
				<label class="display-none" for="none"></label>
				<input type="hidden" id="none">
				<div class="all-checkbox">
					<label class="single-checkbox" for="e">知人の紹介
					  <input type="checkbox" id="e" value="">
					  <span class="checkmark"></span>
					</label>
					<label class="single-checkbox" for="f">メール
					  <input type="checkbox" id="f" value="">
					  <span class="checkmark"></span>
					</label>
					<label class="single-checkbox" for="g">広告
					  <input type="checkbox" id="g" value="">
					  <span class="checkmark"></span>
					</label>
					<label class="single-checkbox" for="t">その他
					  <input type="checkbox" id="t" value="">
					  <span class="checkmark"></span>
					</label>
				</div>
			</div>
			<div class="single-input">
				<label class="flex-basis" for="content_of_inquiry">お問い合わせ内容</label>
				<textarea name="content_of_inquiry" id="content_of_inquiry"  class="input-style textarea-input flex-basis" accesskey="d" tabindex="0"  cols="5" rows="4"></textarea>
			</div>

			<div class="single-input btn-input">
				<label for="send" class="flex-basis"></label>
				<button type="submit" accesskey="c" tabindex="0"  title="send" id="send" value="" name="submit" class="btn flex-basis custom-btn">送信する <img src="img/angle.png" alt="" class="btn-image-angle" /> </button>
			</div>
		</form>

	</div>
</section>
<?php
include('common/inquiry-footer.php');
?>